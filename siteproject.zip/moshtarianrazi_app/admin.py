from django.contrib import admin
from .models import Moshtarian
admin.site.register(Moshtarian)

# Register your models here.
