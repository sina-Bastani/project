from django.db import models

# Create your models here.
class Moshtarian(models.Model):
    project_name = models.CharField(max_length=50,null=True,blank=True)
    project_datial = models.TextField(null=True,blank=True)
    personal_image = models.ImageField(null=True,blank=True,upload_to="codeyad")
    moshtari_name = models.CharField(null=True,blank=True,max_length=50)
    moshtari_semat=models.CharField(null=True,blank=True,max_length=50)

    def __str__(self):
        return self.moshtari_name