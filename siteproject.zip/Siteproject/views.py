from django.shortcuts import render
from home_app.models import Projects
from contactus_app.models import Massege
from headersite_app.models import Header,About_me,Number_view,Maharat,Anche_erare,Click_here,Footer
from moshtarianrazi_app.models import Moshtarian

def project(request):
    if request.method == "POST":
        name = request.POST.get("name")
        lname = request.POST.get("lname")
        email = request.POST.get("email")
        phone = request.POST.get("phone")
        body = request.POST.get("body")
        Massege.objects.create(name=name,lname=lname,email=email,phone=phone,body=body)

    projects=Projects.objects.all()
    header=Header.objects.all().last()
    about_me=About_me.objects.all().last()
    number_view=Number_view.objects.all().last()
    Maharats = Maharat.objects.all()
    Anche= Anche_erare.objects.all()
    click_here=Click_here.objects.all().last()
    moshtarian=Moshtarian.objects.all()
    logo=Footer.objects.all().last()


    return render(request,"index.html",context={"projects":projects,"header":header,"about_me":about_me,"number":number_view,"Maharats":Maharats,"anche":Anche,"click_here":click_here,"moshtarian":moshtarian,"footer_logo":logo})