from django.apps import AppConfig


class ContactusAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'contactus_app'
