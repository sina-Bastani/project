from django.contrib import admin
from .models import Massege

admin.site.register(Massege)

# Register your models here.
