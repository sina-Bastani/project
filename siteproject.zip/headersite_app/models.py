from django.db import models

# Create your models here.

class Header(models.Model):

    logo=models.ImageField(null=True,upload_to="codeyad")

    image=models.ImageField(upload_to="codeyad")
    title=models.CharField(max_length=50)
    subject=models.CharField(max_length=25)
    datial=models.TextField()
    instagram=models.CharField(max_length=100)
    linkedin=models.CharField(max_length=100)


class About_me(models.Model):
    image=models.ImageField(null=True,upload_to="codeyad")
    title=models.CharField(max_length=100)
    datial=models.TextField()


class Number_view(models.Model):
    tajrobe=models.IntegerField(null=True,blank=True)
    moshtariyan = models.IntegerField(null=True, blank=True)
    projects = models.IntegerField(null=True, blank=True)
    jayezeh = models.IntegerField(null=True, blank=True)



class Maharat(models.Model):
    title =models.CharField(max_length=50)
    number=models.IntegerField(null=True,blank=True)


    def __str__(self):
        return self.title





class Anche_erare(models.Model):
    image=models.ImageField(blank=True,null=True,upload_to="codeyad")
    title=models.CharField(max_length=50)
    datial=models.TextField()

    def __str__(self):
        return  self.title


class  Click_here(models.Model):
    image= models.ImageField(null=True,blank=True,upload_to="codeyad")
    adress=models.CharField(max_length=100,null=True,blank=True)



class Footer(models.Model):
    logo=models.ImageField(null=True,blank=True,upload_to="codeyad")


