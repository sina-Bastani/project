from django.contrib import admin
from .models import Header,About_me,Number_view,Maharat,Anche_erare,Click_here,Footer
# Register your models here.

admin.site.register(Header)
admin.site.register(About_me)
admin.site.register(Number_view)
admin.site.register(Maharat)
admin.site.register(Anche_erare)
admin.site.register(Click_here)
admin.site.register(Footer)